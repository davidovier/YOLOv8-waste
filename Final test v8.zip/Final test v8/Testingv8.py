from roboflow import Roboflow

rf = Roboflow(api_key="2CB9ynaTGGWwPR9Q0Mz0")
project = rf.workspace().project("waste-hsysm")
model = project.version(3).model

print(model.predict("your_image.jpg", confidence=40, overlap=30).json())

# visualize prediciton (with boundingbox)
model.predict("your_image.jpg", confidence=40, overlap=30).save("prediction.jpg")
